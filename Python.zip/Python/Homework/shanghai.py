print("Hello and welcome to Shanghai!)
