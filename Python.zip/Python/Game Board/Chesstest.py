#I need to work out how to 'refresh' the player peice/window when a roll() is performed



from tkinter import* #imports TKInter commands
import random #random number selector


window = Tk ()
window.title ("test")

def roll (): #rolling the dice
    playerspace= random.randint(0,4) #my player location is help within this VAR
    print (playerspace) #used during debug earlier
    rollshow.delete (0.0, END) #clears the 'roll display' box
    rollshow.insert (END, playerspace) #shows the roll (playerspace VAR)

def refresh():
       window.destroy()
       exec(open("./Chesstest.py").read())  

playerspace = 0 #VAR which stores player location
space1=PhotoImage (file="black.png") #VARs which store images
space2=PhotoImage (file="white.png")
player=PhotoImage (file="player.png")
rollshow = Text(window, height=1, width=4) #creates/defines the box which shows the player's roll 

Label (window, image=space1) .grid(row=0, column=0) # this is my gameboard
Label (window, image=space2) .grid(row=0, column=1) #NOTE: 'sticky=N' E/S/W can re-anchor image away from centre
Label (window, image=space1) .grid(row=0, column=2)
Label (window, image=space2) .grid(row=0, column=3)
Label (window, image=player) .grid(row=0, column=playerspace) #this is the player gamepeice.  It moves column position as VAR playerspace changes
Button(window, text="roll", width=4, command=roll) .grid(row=1, column=0) #creates the 'roll' button and places it
Button(window, text="Refresh board", command = refresh) .grid(row=2, column=0) #refreshes the game board, but breaks the dice roll, and itself (only works once)

rollshow.grid (row=1, column=1) #places my rollshow box.  I have no idea why this requires two lines where anything else requires one

window.mainloop () #creates the window, calls it window, creates the space where things should appear.
                    # i am guessing this means I can create multiple windows running from the same script but I havn't tested this
