rows = int(input("How many rows do you want? "))
cols = int(input("How many columns do you want? "))

squares = (rows * cols)

num = 0
num2 = 1

for i in range (squares):
    num = num+1

    if num > 10:
        num2=num2+1

    else:
        Label (window, image=space1) .grid(row=num2, column=num)a
