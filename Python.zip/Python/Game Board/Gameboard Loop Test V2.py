from tkinter import*
import tkinter
import random

window = Tk()
window.title("Gameboard loop test V2")

addSquare = 0
vert = 0
hori = 0
space1 = PhotoImage(file="black.png")

while addSquare == 0:
    if hori > 10:
        vert = vert + 1
        continue
    else:
        hori = hori + 1
        Label(window, image=space1) .grid(row=vert, column=hori)

        if hori > 10 and vert == 10:
            addSquare = addSquare + 1

        else:
            continue

window.mainloop()

        
    
