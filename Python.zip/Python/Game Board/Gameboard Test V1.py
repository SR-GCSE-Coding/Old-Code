from tkinter import*
import random

window = Tk()
window.title("Gameboard test V1")

def roll ():
    playerspace= random.randint(1,6)
    print (playerspace)
    rollshow.delete (0.0, END) 
    rollshow.insert (END, playerspace)

space1=PhotoImage (file="black.png")
space2=PhotoImage (file="white.png")
rollshow = Text(window, height=1, width=4)

Label (window, image=space1) .grid(row=0, column=0)
Label (window, image=space2) .grid(row=0, column=1)
Label (window, image=space1) .grid(row=1, column=1)
Label (window, image=space2) .grid(row=1, column=0)
Button(window, text="roll", width=4, command=roll) .grid(row=2, column=0)
rollshow.grid (row=2, column=1)

window.mainloop()
