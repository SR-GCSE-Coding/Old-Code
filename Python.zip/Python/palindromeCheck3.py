for_str = input("Enter your word ")

#this code removes any capital letters from the string
for_str = for_str.casefold()

#this code creates a variable that is the reverse of the input
rev_str = reversed(for_str)

#this checks if the string is equal to it's reverse
if list(for_str) == list(rev_str):
    print("That word is a palindrome")

else:
    print("That word is not a palindrome")
