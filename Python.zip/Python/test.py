print("He" + "llo" *5)
print("Hello" * ( 2 + 2 ))
print("")

print("**\n**")
print("")
print((("*"* 3) + "\n") * 3)
print("")
print("****\n" * 4)
print("")

print("Hello \nworld!")
print("")




