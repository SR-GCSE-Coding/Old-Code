numtbl=int(input("Please enter a number: "))
numend=int(input("What number will it stop with? "))
numfin=numend+1

for x in range (1,numfin):
    print(numtbl,"multiplied by " ,x,"is",numtbl*x)
