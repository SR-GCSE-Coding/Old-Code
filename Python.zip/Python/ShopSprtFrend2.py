shop=int(input("How much time do you spend shopping? "))
frend=int(input("How much time do you spend with friends? "))
sport=int(input("how many hours do you spend playing sport? "))

print("You spend ",shop+frend+sport," doing things outside of school ")
