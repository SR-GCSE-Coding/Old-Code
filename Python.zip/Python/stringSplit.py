x = 'blue,red,green'
x.split(",")
a,b,c=x.split(",")
