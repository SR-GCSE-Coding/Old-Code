password = ("123abc@£$")
P = list(password)
print (P)
length = len(password)
Security = 0

for i in range (length):
    if i == ["1","2","3","4","5","6","7","8","9","0","@","#","%","£","$"]:
        Security += 1

    else:
        Security -= 0

print(Security)
