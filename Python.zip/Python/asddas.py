
z = foo( 3, 6 )

def foo ( x, y ):
    return X + y
