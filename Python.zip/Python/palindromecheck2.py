word=input("What is the word you want me to check? ")
length=len(word)

for i in range( length ):
    if word[i] == word[length - i]:
        print("These letters are palindromic")

    else:
        print("These letters are not palindromic. ")
