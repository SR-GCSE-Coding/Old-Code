num1=input("Gimme password ")
print("")

num2=input("Gimme password again ")

while num1 != num2:
    print("That's not the same!!!!!!")
    num2=input("Gimme password again, correct one this time ")
    print("")

else:
    print("That's a good password")
