loop=("y")

while loop == ("y"):
    num1=int(input("Please enter a number "))
    print("")

    if num1 >= 10 and num1 <= 20:
        print("That is a valid number")
        print("")
        loop=("n")

    else:
        print("That is not a valid number")
        loop=input("Do you want to enter another number? [y/n] ")
        ("")
        
