import argparse
from Tkinter import Tk, Canvas, Frame, Button, BOTH, TOP, BOTTOM

boards = ['debug', 'n00b', 'l33t', 'error'] #available sudoku boards
MARGIN = 20     #pixels around the board
SIDE = 50   #width of every board cell
WIDTH = HEIGHT = MARGIN * 2 + SIDE  * 9     #width and height of thw whole board
