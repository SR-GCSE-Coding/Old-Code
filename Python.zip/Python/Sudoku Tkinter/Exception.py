class SudokuError(Exception):
    """
    An application specific error.
    """
    pass
