class SudokuBoard(object):
    """
    sudoku board representation
    """
    def __init__(self, board_file):
        self.board = __create_board(board_file)

    def __create_board(self, board_file):
        pass
