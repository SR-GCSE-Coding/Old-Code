def loop():
    for x in range (num1):
        print("Your number is",num1)

#this code defines loop as a for loop that prints num1 num1 amount of times

num1 = int(input("Please enter a number: "))

#this code creates a variable called num1 that the user has to choose

loop()

#this code runs the loop command
