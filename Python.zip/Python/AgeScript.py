age = int(input("What is your age? "))

#this code records a variable called age

if age >= 50 and age <= 69:
    print("Statistically you are unlikely to live another 50 years")

#this code will print the statement if the age entered is between 50 and 69

elif age >= 70 and age<= 79:
    print("You almost definitely will not live another 50 years")

#this code will print the statement if the age entered is between 70 and 79

elif age >= 80:
    print("If you live another 50 years you will have lived longer than anybody else")

#this code will print the statement if the age entered is above 80

else:
    print("In 50 years you will be ", age + 50 ,"years old")

#this code will print the statement if the age entered is less than 50.
#the code , age + 50 , takes the entered age and adds 50 to it before printing it in the middle of the sentence
