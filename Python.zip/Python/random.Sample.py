import random
my_randoms = random.sample(range(100), 10)

print(my_randoms)
