num=int(input("Please enter your first number: "))
num2=int(input("Please enter a second number: "))
num3=num2+1

while num != num3:
    numsq=num*num
    print("The square of ",num," is ",numsq)
    num = num+1
    
        
        



