def multiply(a, b):
    a * b
