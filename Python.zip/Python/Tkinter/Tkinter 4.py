import tkinter

window=tkinter.Tk()

buttons = [i for i in range(10)] + ["+","-","/","x","="]

for b in buttons:
    btn = tkinter.Button(window, text=b)
    btn.pack(side=tkinter.LEFT)
