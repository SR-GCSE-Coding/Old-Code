#This code is copied from http://usingpython.com/python-widgets/


import tkinter

window=tkinter.Tk()
window.title("The best code")
window.geometry("300x300")

#create a label widget under the variable 'lbl'
lbl = tkinter.Label(window, text="Label")
#create a text entry widget under the variable 'ent'
ent = tkinter.Entry(window)
#create a button widget under the variable 'btn'
btn = tkinter.Button(window, text="Button")

#pack (add) the widgets into the window
lbl.pack()
ent.pack()
btn.pack()

#draw the window, and start the 'application'
window.mainloop()
