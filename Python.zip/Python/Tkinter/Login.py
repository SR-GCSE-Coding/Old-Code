#this code was made using the guide on http://usingpython.com/making-widgets-look-nice/


import tkinter

window=tkinter.Tk()
window.configure(background="#312B97")
photo = tkinter.PhotoImage(file="Miltoncross.gif")
w=tkinter.Label(window, image=photo)
w.pack()


#create a label wiget with the name 'username'
lblUsername = tkinter.Label(window, text="Username:", bg="#312B97")
#create a label widget with the name 'password'
lblPassword = tkinter.Label(window, text="Password:", bg="#312B97")
#create a label widget with the name 'lblLogin'
lblLogin = tkinter.Label(window, text="Please login to continue:", fg="#a1dbcd", bg="#312B97", font=("Helvetica", 16)) 

#create a text entry with the name 'ent'
#I had to add a second text entry because I found out that widgets can only be packed once
entUsername = tkinter.Entry(window)
entPassword = tkinter.Entry(window)

#create a button with the name 'btn'
btn = tkinter.Button(window, text="Enter", fg="#a1dbcd", bg="#383a39")

#pack (add) the widgets to the window
lblLogin.pack()
lblUsername.pack()
entUsername.pack()
lblPassword.pack()
entPassword.pack()
btn.pack()

#draw the window and start the 'application'

window.mainloop()
