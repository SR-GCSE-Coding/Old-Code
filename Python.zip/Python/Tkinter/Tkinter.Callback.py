import tkinter

window=tkinter.Tk()
window.title("Commands")
window.geometry("200x50")

presses=0

def addClick():
    global presses
    presses += 1
    lbl.configure(text=presses)

lbl=tkinter.Label(window, text=presses)
btn=tkinter.Button(window, text="Click me", command=addClick)

btn.pack(fill=tkinter.X)
lbl.pack()

window.mainloop()
