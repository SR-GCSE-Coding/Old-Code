import random

pos1=0
pos2=0

while pos1<49 and pos2<49:
    num1=random.randint(1,6)
    num2
    num3
    num4
