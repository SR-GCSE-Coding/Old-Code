#import the module to use pickle
import pickle
#create the phonebook
phonebook = {"G" : {"home":"07834210928","work":"01137892472"}, "B" : {"home":"07834210928","work":"01137892472"} }
#save the phonebook
pickle.dump( phonebook, open( "phoneBook.txt", "wb"))
