import pickle
import tkinter

window=tkinter.Tk()

phonebook = pickle.load( open( "phoneBook.txt", "rb") )

