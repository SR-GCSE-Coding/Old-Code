#this code was made using the guide on  http://usingpython.com/dynamically-creating-widgets/

#import the tkinter module
import tkinter

#create a new window and set it's title
window = tkinter.Tk()
window.title("Colours")

#create a list variable containing the colours
colours=["red","yellow","pink","green","purple","orange","blue"]

#loop through each colour
for c in colours:
    #create a new button, using the text/bg of the list item
    b = tkinter.Button(text=c, bg=c)
    #pack the button, filling up the x axis
    b.pack(fill=tkinter.X)

#draw the window and start the program
window.mainloop()
