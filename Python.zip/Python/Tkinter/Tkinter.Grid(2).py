import tkinter

window=tkinter.Tk()

for n in range(3):
    for r in range(4):
        tkinter.Label(window, text='R%s/C%s'%(n,r)).grid(row=n, column=r)

window.mainloop()
