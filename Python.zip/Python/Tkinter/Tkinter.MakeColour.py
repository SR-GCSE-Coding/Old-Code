import tkinter

window=tkinter.Tk()
window.title("Red Blue")

def makeBlue():
    window.configure(background="#312b97")

def makeRed():
    window.configure(background="red")

blue=tkinter.Button(window, text="Make blue", command=makeBlue, bg="#312b97", fg="#a1dbcd"
                    )
red=tkinter.Button(window, text="Make red", command=makeRed, bg="red")

blue.pack()
red.pack()

window.mainloop()
