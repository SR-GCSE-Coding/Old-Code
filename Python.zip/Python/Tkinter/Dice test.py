from random import randint
import random

pos1 = 0
pos2 = 0


while pos1 < 49:
    num1=random.randint(1,6)
    num2=random.randint(1,6)

    if num1 == num2:
        pos1 = pos1 - num1 - num2
        print("Player 1 is on square ",pos1)

    else:
        pos1 = pos1 + num1 + num2
        print("Player 1 is on square ",pos1)




while pos2 < 49:
    num3=random.randint(1,6)
    num4=random.randint(1,6)

    if num3 == num4:
        pos2 = pos2 - num3 - num4
        print("Player 2 is on square ",pos2)

    else:
        pos2 = pos2 + num3 + num4
        print("Player 2 is on square ",pos2)

        
   
