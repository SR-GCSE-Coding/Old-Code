import tkinter

window = tkinter.Tk()
window.configure(background="#312B97")

names = ["Gordon Freeman","Dr. Kleiner","Barney Calhoun","Alyx Vance"]

ttl = tkinter.Label(window, text="Click the button to choose who to call", font=("Helvetica", 16), bg="#312b97", fg="#a1dbcd")

ttl.pack()
for n in names:
    nm = tkinter.Label(window, text=n, bg="#312B97", fg="#a1dbcd")
    btn = tkinter.Button(window, text=("Call",n), bg="#383a39", fg="#a1dbcd")
    nm.pack(fill=tkinter.X)
    btn.pack(fill=tkinter.X)
