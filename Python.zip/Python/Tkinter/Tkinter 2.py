#this program was made using https://www.python-course.eu/tkinter_layout_management.php
#the colours were copied using https://html-color-codes.info/colors-from-image/
#with extra support from http://usingpython.com/python-widgets/

import tkinter

root=tkinter.Tk()
root.geometry("200x200+200+200")

lblRed = tkinter.Label(root, text="Red Sun", bg="#FF0000", fg="white")
lblGrn = tkinter.Label(root, text="Green Grass", bg="#00FF00", fg="black")
lblBlu = tkinter.Label(root, text="Blue Sea", fg="white", bg="#0000FF")

lblRed.pack()
lblGrn.pack()
lblBlu.pack()

root.mainloop()
