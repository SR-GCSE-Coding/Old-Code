mon = int(input("What is your monthly income? ")
phon = int(input("What is your monthly phone bill? ")
trav = int(input("How much do you spend on transit each month? ")
