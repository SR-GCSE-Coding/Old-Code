l = int(input("Enter one of the lengths of the edges of your box "))
w = int(input("Enter the length of another of the edges "))
h = int(input("Enter the length of the last edge "))

print("Your box's volume is ", l*w*h)
