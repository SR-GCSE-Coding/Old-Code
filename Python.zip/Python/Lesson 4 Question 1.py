dartmoor = int(input("How old are your parents? "))
bodmin=int(input("How old are you? "))
yorkshire=dartmoor-bodmin

if yorkshire >= 20 and yorkshire < 25:
    print("That is an okay age to have a child and your parents are at least partly responsible adults")

elif yorkshire < 16:
    print("That is a terrible time to have a child and your parents are probably not very responsible people")

elif yorkshire > 25 and yorkshire < 35:
    print("That was very good time to have a child and your parents are probably very responsible people")

else:
    print("Having a child at this age greatly increases the chance you would have had birth defects")
    
