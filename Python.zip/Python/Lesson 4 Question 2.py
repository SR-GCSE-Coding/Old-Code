from random import randint
import random

list1=[]
list2=[]

for i in range (4):
    number=random.randint(0,14)
    list1.append(number)

print("Try to guess the pin ")

tryagain = 1

while tryagain == (1):
    answer=int(input("what do you think the first number is?"))
    list2.append(answer)
    answer2=int(input("what do you think the second number is?"))
    list2.append(answer2)
    answer3=int(input("what do you think the third number is?"))
    list2.append(answer3)
    answer4=int(input("what do you think the fourth number is?"))
    list2.append(answer4)

    if list2==list1:
        print("you guessed the number correctly")

    else:
              print("you didn't guess the number")
              tryagain=int(input("do you want to play again?"))


    

