m1=[]
run = ("y")
i=0

while run == ("y") or run == ("Y"):
    i = i + 1
    film=str(input("Enter one of your No.%s favourite hobby. " %i))
    m1.append(film)
    run=str(input("Do you want to add another hobby? [Y/N] "))

    if run == ("n") or run == ("N"):
        m1.sort()
        print(m1)

    else:
        continue
