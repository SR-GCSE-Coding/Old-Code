import random

rand = random.randint(111,999)

#dev code
print(rand)
playagain=("y")
i=0

while playagain == ("y") or playagain == ("Y"):
    i=i+1
    guess=int(input("Guess the number "))
    print("----------")
    if guess != rand:
        print("That guess is incorrect")
        print("You have played %i times" %i)
        playagain==input("Do you want to play again? ")
        print("----------")

    else:
        print("That guess is correct")
        print("It took you %i times to guess the number" %i)
        playagain = ("n")
