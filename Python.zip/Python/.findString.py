string="those who seek to find"
if 'seek' in string:
    print('Success!')
