Pass1Entered = 0
Security = 0

if Pass1Entered == 0:
    print("Enter your password please. ")
    Pass1 = str(input("> "))
    Pass1Entered += 1

ResetPass = str(input("Do you want to reset your password? "))

while ResetPass == ("no") :
    print("Then why are you here? ")
    break

while ResetPass == ("yes") :
    print("enter your new password; it can't be the same as your old password ")
    Pass2 = str(input("> "))

    if Pass2 == Pass1 :
        print("Your new password can't be the same as your old password! ")
        ResetPass = ("yes")

    elif Pass2 != Pass1:

        length = len(Pass2)
        Security = Security + length

        for i in range(length):
            if i == ("*") or i == ("&") or i == ("%") or i == ("£") or i == ("$") or i == ("#") or i == ("@") or i == ("1") or i == ("2") or i == ("3") or i == ("4") or i == ("5") or i == ("6") or i == ("7") or i == ("8") or i == ("9") or i == ("0"):
                Security += 1

        if Security >= 5:
            print("New password set")
            print("Security rating is %s " %Security)
            Pass1 = Pass2
            ResetPass = ("no")

        else:
            ResetPass = ("yes")

        
    
    

