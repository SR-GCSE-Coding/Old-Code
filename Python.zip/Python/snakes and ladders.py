from random import *

#variables
player1=0
player2=0

def board():
    print("I--------------------I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I00000000000000000000I")
    print("I12000000000000000000I")
    print("I--------------------I")
#variables

#play loop
playagain=("y")
board()

while playagain==("y") or playagain==("Y"):
    di=randint(1,6)
    print(di)

