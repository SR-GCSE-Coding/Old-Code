for x in range(1,6):
    print("Hello world", x)
