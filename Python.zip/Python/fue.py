in [40]:'fue'+ u'\u0301'
out[40]:'fue'
