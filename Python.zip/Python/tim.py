import time

tim=time.time()
time.sleep(5)
tim2=time.time()
local1=time.ctime(tim)
local2=time.ctime(tim2)

tim3=tim2-tim

print(local1)
print(local2)
print(tim3)
