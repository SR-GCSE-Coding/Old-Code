from random import randint
import random


for i in range (4):
    number=random.randint(0,9999)
    
print("Try to guess the pin ")

tryagain="y"

while tryagain == ("y"):
    ("")
    ("")
    answer=int(input("What do you think the number is?"))
    ("")
    ("")

    if answer==number:
        print("You guessed the number correctly")
        ("")
        ("")

    else:
              print("You didn't guess the number")
              ("")
              ("")
              tryagain=input("Do you want to play again?")
              ("")
              ("")


    

