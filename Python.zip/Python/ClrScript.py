clr = input("what is your favourite colour? ")
#this code asks for the user's favourite colour and saves the answer as a variable

if clr == ("green"):
    print("That's my favourite colour as well")

elif clr == ("Green"):
    print("That's my favourite colour as well")

#these two pieces of code reply to gree or Green by saying that it's the speaker's favourite colour as well

else:
    print("That's a good colour, but I prefer green")

#this code responds to any other input by saying that the speaker prefers green
