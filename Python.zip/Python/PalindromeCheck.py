pali=[]
go=1
tot=len(pali)
length=int(input("Howlong is the word you want to test? "))

for i in range(length):
    leter=input("Enter a letter")
    pali.append(leter)

while go == 1:
        if pali[1] != pali[tot-1]:
            print("The sentence is not a palindrome")
            go=0

        else:
            print("The sentence is a palindrome")
            go=0
