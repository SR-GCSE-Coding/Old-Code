numtbl = []

numamount=int(input("How many numbers do you want in your list? "))
#this gets the variable numamount which is how many variables there will be in
#the list numtbl

for x in range(numamount):
    num=int(input("enter a number: "))
    numtbl.append(num)
#this code adds numbers to the list, adding the amount of numbers stated earlier;numamount.

x=0
for i in range(numamount):
    x=x+numtbl[i]
#this code adds all of the variables in numtbl together.

print("Your average is ",x/numamount)


    


