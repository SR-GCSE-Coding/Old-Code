class Dog:

    species = 'mammal'

    def __init__(self, name, age):
        self.name = name
        self.age = age

poppy = Dog('Poppy', 3)

print(poppy)

print('%s is %i.' %(poppy.name, poppy.age))

print('%s is a %s' %(poppy.name, poppy.species))

for i in range(species):
