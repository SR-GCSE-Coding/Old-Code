import itertools
from random import randint

lst1 = []
length = int(input("How long do you want the code? "))
for i in range (length):
             rand = randint(0,9)
             lst1.append(rand)

print(lst1)
print("-------------------")

array = itertools.permutations(lst1)

for eachpermutation in array:
    print(eachpermutation)
