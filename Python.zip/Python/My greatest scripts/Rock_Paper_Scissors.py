from random import randint

#create a list of play options
play = ["rock","paper","scissors"]

#assign a random play to the computer
computer = play[randint(0,2)]

#set looper variable to run the code
looper = ("Y")

while looper == ("Y") or looper == ("y"):
    player = input("Do you want to play rock, paper, or scissors? ")

    if player == computer:
        print("You tied")

    elif player == "rock":
        if computer == "scissors":
            print("Rock destroys scissors, you win")

        else:
            print("Paper covers rock, you lose")

    elif player == "paper":
        if computer == "rock":
            print("You beat the computer")

        else:
            print("The computer beat you")

    elif player == ("scissors"):
        if computer == ("paper"):
            print("You beat the computer")

        else:
            print("The computer beat you")

    else:
        print("That is not a valid play, check your spelling")

    looper = input("Do you want to play again? [Y/N] ")
    computer = play[randint(0,2)]

    
