#import the 'random' script
import random

#this code sets the difficulty so that the game can be harder or easier
dif=int(input("What difficulty do you want to play? [1/2/3] "))

#the random number has three digits on the lowest difficulty
if dif == 1:
    print("Try to guess the number. It's a three digit number.")
    print("")
    random = random.randint(111,999)
    pos=[0,1,2,3]
    length = 3

#the random number has five digits on the hardest difficulty
elif dif == 3:
    print("Try to guess the number. It's a five digit number.")
    print("")
    random = random.randint(11111,99999)
    pos=[0,1,2,3,4,5]
    length = 5
    
#the random number has four digits on the middle difficulty
elif dif == 2:
    print("Try to guess the number. It's a four digit number.")
    print("")
    random = random.randint(1111,9999)
    pos=[0,1,2,3,4]
    length = 4

else:
    print("That is not a valid difficulty.")

#create a list from the random number
random_lst=[int(x) for x in str(random)]
playagain=("y")
gamenum = 0

#this code is the meat and gravy, it performs the actual functions and takes all of the important inputs
while playagain == ("y") or playagain == ("Y"):
    gamenum = gamenum + 1
    print("********************************")
    print("|You must now guess the number.|")
    print("********************************")
    print("")
    #this takes the user's guess as a list under the list name 'guess'
    guess = int(input(">"))
    guess_lst=[int(x) for x in str(guess)]
  
    
    #this code runs if the guess is correct
    if guess == random:
        print("You guessed the number correctly")
        print("You played %s times" %gamenum)
        playagain=("n")

    #this code runs if the difficulty is above easy and the guess is wrong
    elif dif == 3 and guess != random:
        print("this is the hard loss prompt")
        print("You did not guess correctly.")
        print("You have played",gamenum,"times so far")
        print("")
        playagain=input("Do you want to play again? [Y/N] ")
        print("")

    elif dif == 2 and guess != random:
        print("This is the medium failure prompt")
        print("You did not guess correctly")
        print("You have played",gamenum,"times so far")
        print("")
        print("-------------------------------------------")

        if guess_lst[0,3] == random_lst[0,3]:
            print("One of the numbers in your guss is correct")

        print("-------------------------------------------")

        print("")
        playagain=input("Do you want to play again")
        print("")
        

    #this code runs if the difficulty is 1 and the guess is wrong    
    elif dif == 1 and guess!= random:
        print("")
        print("This is the easy failure prompt")
        print("")
        #this code tells the user which of the digits in their guess was correct
        print("-------------------------------------------")
        if guess_lst[0] == random_lst[0]:
            print("The first digit of your guess is correct")
        else:
            print("The first digit of your guess is incorrect")

        if guess_lst[1] == random_lst[1]:
            print("The second digit of your guess is correct")
        else:
            print("The second digit of your guess is incorrect")

        if guess_lst[2] == random_lst[2]:
            print("The third digit of your guess is correct")
        else:
            print("The third digit of your guess is incorrect")
        print("-------------------------------------------")
        print("")
        print("You have played %s times so far" %gamenum)
        playagain=input("Do you want to play again? [Y/N] ")
        print("")

    #this should never run
    else:
        print("How did you get here, this should be physically impossible")
    
    
