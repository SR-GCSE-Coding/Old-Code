x = dict1["model"]
print (x)
