carDict = {                 #defines the dictionary and adds variables
    "brand": "Rolls Royce",
    "model": "Phantom",
    "year": "2017"
}

def ital():
    print("----------------------------------------")
    
print(carDict)

ital()

x = carDict["brand"]#gives the variable x the value of brand
print (x)

ital()

y = carDict.get("model")#gives the variable y the value of model
print (y)

carDict["year"] = 1917#changes the year variable to 1917

ital()

print (carDict["year"])#calls the year and then prints it

ital()

for z in carDict:#prints all of the variables in the dictionary
    print(carDict[z])

ital()

for f in carDict.values():#prints all of the variables in a dictionary
    print(f)

ital()

if "year" in carDict:
    print("Year is a key in this dict")

else:
    print("No, year is not a key")

ital()

print(len(carDict))

ital()

