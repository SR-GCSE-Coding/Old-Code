wrdlst=[]

for i in range(3):
    word=input("Please enter the first word of your three-word sentence: ")
    wrdlst.append(word)

print(wrdlst)
print(wrdlst[1])
print(wrdlst[2])
print(wrdlst[0])
