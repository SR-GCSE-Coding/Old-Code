import time

time1=time.time()
time.sleep(65)
time2=time.time()

local1=time.ctime(time1)
local2=time.ctime(time2)

print(local1)
print(local2)
