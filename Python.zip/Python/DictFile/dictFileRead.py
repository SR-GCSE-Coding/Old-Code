f = open("dictFile.txt", "r")
for x in f:
    print(x)
