d = open("dictFile.txt", "w")
d.write( str(dict) )


with open("dictFile.txt", "a") as file:
    file.write(dict)
