createNew = str(input("Do you want to create a new account? "))

while createNew == ("y") or createNew == ("Y"):
    user = str(input("What do you want your username to be? make sure to choose something sensible! "))
    age = int(input("How old are you? "))
    year = int(input("What year group are you in? "))
    
login = 




d = open("dictFile.txt", "w")
d.write( str(dict) )


with open("dictFile.txt", "a") as file:
    file.write(dict)
