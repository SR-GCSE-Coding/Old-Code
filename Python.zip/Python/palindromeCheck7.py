pali=[]

for i in range ( 7 ):
    letter=input("Enter the letter ")
    pali.append(letter)

if pali[0] == pali[6] and pali[1] == pali[5] and pali[2] == pali[4]:
    print("The sentence is a palindrome. ")
    
