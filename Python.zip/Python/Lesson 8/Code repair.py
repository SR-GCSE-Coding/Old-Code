#this imports the 'time' module and defines the menu/
import time

menuchoice = 0

def menu():
    print("*****menu*****")
    print('')
    print('1. Display my name')
    print('2. Display my age')
    print('3. Diplay my address')
    print('')

menu()

#this code uses a while loop to perform the main function
while True:
    try:
        while (menuchoice < 1) or (menuchoice > 3):
            menuchoice = int(input('Which menu do you want to show? '))
        break
    except ValueError:
        print('That is not a valid menu')

#this checks the answer and changes it's output based on the answer.
if menuchoice== 1:
    print('Mr Wickins')

if menuchoice == 2:
    print('29 years')

if menuchoice == 3:
    print('Sidmoth College')

print('Goodbye')
    
