print("This is my Börk beta test")
print('')
print('[------------------------------------------------------------------------------]')
print('[##############################################################################]')
print('[##############################################################################]')
print('[------------------------------------------------------------------------------]')
print('')
print("There is a door in front of you.")
command=input("You go through the door, there are two pedestals. \nOn one is a sword \nOn the other is a spear \nWhich will you choose? \n>")

if command == 'sword':
    print("You pick up the sword, iron bars drop behind you. You are stuck.")
    print("Slowly, two doors grind upwards. Will you go \nLeft \nOr \nRight?")
    command=input('>')

    if command == 'right':
        print("You go to the right.")
        print("You notice a skeleton lying on the ground with sword in hand. As you approach the skeleton there is a creaking sound as it stands up")
        print("Will you \nFight \nOr \nRun?")
        command=input('>')

    if command == 'left':
        print("You walk through the left door and go down the hallway. You step on a pressure pad and metal bars drop down behind you.")
        print("You are stuck, and starve to death")

        if command == 'fight':
            print("You attempt to fight the skeleton, but it stabs you with it's spear.")
            print("You are dead")

        if command == 'run':
            print("You attempt to run but the skeleton is faster and catches up to you, piercing right through your chest with it's spear")
            print("You are dead")


if command == 'spear':
    print('you pick up the spear and metal bars drop around the sword behind you')
    print('In front of you are two doors, will you go \nLeft \nOR \nRight?')
    command=input('>')

    if command == 'right':
        print("You go to the right.")
        print("You notice a skeleton lying on the ground with sword in hand. As you approach the skeleton there is a creaking sound as it stands up")
        print("Will you \nFight \nOr \nRun?")
        command=input('>')

    if command == 'left':
        print("You walk through the left door and go down the hallway. You step on a pressure pad and metal bars drop down behind you.")
        print("You are stuck, and starve to death")

        if command == 'fight':
            print("You attempt to fight the skeleton, but it stabs you with it's spear.")
            print("You are dead")

        if command == 'run':
            print("You attempt to run but the skeleton is faster and catches up to you, piercing right through your chest with it's spear")
            print("You are dead")
