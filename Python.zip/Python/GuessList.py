import random

dif=int(input("How many numbers do you want? "))
numlst=[]
guesslst=[]
playagain=("y")
gamenum = 0

print("Try to guess the number. It's a ",dif," digit number.")
print("")

for i in range (dif):
    randnum=random.randint(0,9)
    numlst.append(randnum)

while playagain == ("y") or playagain == ("Y"):
    gamenum = gamenum + 1
    for b in range (dif):
        guess=int(input("What do you think number",b," is? "))
        guesslst.append(guess)

for n in range (dif):
    if numlst[n]==guesslst[n]:
        print("The number",guesslst[n],"in position", n,"is correct")

    else:
        print("The number",guesslst[n],"in poition",n,"is not correct")

    
