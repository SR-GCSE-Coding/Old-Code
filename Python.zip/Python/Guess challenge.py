import random

#this code sets the difficulty so that the game can be harder or easier
dif=int(input("What difficulty do you want to play? [1/2/3] "))

#this code changes the number to guess based on the difficulty
if dif == 1:
    print("Try to guess the number. It's a three digit number.")
    print("")
    random = random.sample(range(9), 3)
    length = 3
    
elif dif == 3:
    print("Try to guess the number. It's a five digit number.")
    print("")
    random = random.sample(range(9), 5)
    length = 5
    

elif dif == 2:
    print("Try to guess the number. It's a four digit number.")
    print("")
    random = random.sample(range(9), 4)
    length = 4

else:
    print("That is not a valid difficulty.")

#this is just variables
random = str(random)
playagain=("y")
gamenum = 0
#dev code, remove the # for development.
print("-------------------")
print("Random ==",random)
print(length)
print("-------------------")

#this code is the meat and gravy, it performs the actual functions and takes all of the important inputs
while playagain == ("y") or playagain == ("Y"):
    gamenum = gamenum + 1
    print("------------------------------------------------------------------------------")
    print("You must now guess the number, your guess requires spaces between each number.")
    print("------------------------------------------------------------------------------")
    #this takes the user's guess as a list under the list name 'guess'
    guess = [int(x) for x in input().split()]
    #dev code
    print("-------------------")
    print("Guess ==",guess)
    print("-------------------")
    
    #this code is meant to print "Testing... Testing..." if 'guess' is correct but it isn't working
    if dif == 1 and guess == random:
        print("This is the easy win prompt")

    #this code should run if the code is incorrect but instead it always runs.
    elif dif != 1 and guess != random:
        print("this is the hard/medium loss prompt")
        print("You did not guess correctly.")
        print("You have played",gamenum,"times so far")
        print("")
        playagain=input("Do you want to play again? [Y/N] ")
        print("")

    elif dif == 1 and guess!= random:
        print("This is the easy failure prompt")

    else:
        print("this is the hard/medium win prompt")
    
    
