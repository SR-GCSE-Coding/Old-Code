import random

randomNum2=random.randint(0,1)
nameList=["Rosie","Jennifer"]
name=nameList[randomNum2]

for i in range(10):
    print("%s sux" %name)
