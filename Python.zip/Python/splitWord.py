s1=input("Enter a word ")
length=len(s1)
