def hello_world(foo, bar='bye'):
    print(foo)
    print(bar)
