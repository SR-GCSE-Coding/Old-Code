from random import*
import time

camDist=["100","250","500","1000","2000"]
camDist1=int(input("What is the distance between the cameras (Yards) [0,1,2,3,4]"))
dist=str(camDist[camDist1])
ran=randint(5,15)
sec=time.time()
local1=time.ctime(sec)
time.sleep(ran)
sec2=time.time()
local2=time.ctime(sec2)
#local1=int(local1)
#local2=int(local2)
distInt=int(dist)
sec3=sec2-sec
sec3Int=int(sec3)
average=distInt/sec3Int

print("The car passed camera 1 at %s and camera 2 at %s. It took the car %i seconds to travel %s yards. That means the car is travelling an average of %i yards per second" %(local1,local2,sec3,dist,average))
