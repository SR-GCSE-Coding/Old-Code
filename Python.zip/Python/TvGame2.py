tv=int(input("How much time do you spend watching tv? "))
game=int(input("How much time do you spend playing games? "))

time=game+tv
year=time*365
percent=time/24
percentr=round(percent,2)
#the round command rounds to decimal places, the number after the variable to round is how many decimal places to round to

print("you spend ",time," hours playing games and watching tv. After a year that would be",year," hours. You spend",percentr,"percent of your time doing recreational activities.")




         

               
