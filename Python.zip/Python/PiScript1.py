Pi=input("what is Pi to 3 decimal place? ")

if Pi == ("3.142"):
    print("You're correct, that is Pi!")

else:
    print("No, that's not Pi")
