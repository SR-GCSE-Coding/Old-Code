import random
sentence=input("Enter a sentence ")
sentence_lst=list(sentence)
a_lst=['å','á', 'à', 'â']

if 'a' in sentence_lst:
    rand = random.randint(0,3)
    aran=a_lst[rand]
    sentence_lst[sentence_lst.index('a')] = aran

print(sentence_lst)
    

    

