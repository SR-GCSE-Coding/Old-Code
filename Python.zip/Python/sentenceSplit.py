import random
print("Enter your sentence")
print("Please only enter a three word sentence")
text=input("> ")
first, middle, last = text.split()
print(first, last)
