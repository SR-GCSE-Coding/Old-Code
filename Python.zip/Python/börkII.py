g=("Guide: ")
m=("Mysterious Voice: ")
print("",g,"Welcome to Börk II. \n",g,"This is a text adventure game. \n",g,"This world is one filled with magic, and evil. \n",g,"Luckily, there are no spiders though. Don't ask if that's true, please.")
start=1
items = {

        }

commands = {

                " i" : "see inventory",


           }

print(" Guide: What do you want to do first? ")
while start == 1:
    command=input(" >")

    if len(command) == 0:
        continue

    if len(command) > 0:
        verb = command[0].lower()

    if len(command) > 1:
        item=command[1].lower()

    if verb == "?":
        for key in commands:
            print(key + " : " + commands[key])
        print("\n")

    elif 'spiders' or 'spider' in start:
        print("",g,"I said don't ask! \n",m,"(There are spiders)\n",g,"No there aren't, he's lying.")
