name = input("what is your name? ")
age = int(input("how old are you? "))
#these input commands get your name and age as variables

print("Hello", name,", you are", age, "years old")
#this print command prints your name and age inbetween the text in speech marks, if
#name and age are in speech marks, it will just enter them as words and not variables
