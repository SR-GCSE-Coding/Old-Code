password = (" ")

while password!="a very secure password":
    password = input("please enter my password hint: it's a very secure password")

print ("you guessed my password, it wasn't very secure :(")
