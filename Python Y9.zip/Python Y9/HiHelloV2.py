print ("Hi")
print ("Hello")
