name = input("what is your name? ")

print("")

num1 = input ("please enter a number: ")
num2 = input ("please enter a second number: ")
#this code takes two numbers and stores them as a variable

num1 = int(num1)
num2 = int(num2)
#this code converts the variables to an integer number

num3 = num1 * num2 * 2
#this code multiplies the two given numbers by each other and then by two

print ("your answer is: " , num3)
#this shows the final result

print (num3 , "is an even number")


print("")


print ("this code will work out the volume of a cuboid, make sure all the measurements are in the same units")

side1 = input("enter the length of the first side: ")
side2 = input("enter the length of the second side ")
side3 = input("enter the length of the third side ")

side1 = int(side1)
side2 = int(side2)
side3 = int(side3)

volume = side1 * side2 * side3

print ("the volume of the cube is: " , volume)


print("")


color = input("what is your favourite colour? ")

if color == "blue":
    print("what a nice colour")

else:
    print("that colour sucks")


print("")


age = int(input("how old are you? "))

age50 = age + 50

print ("in 50 years you will be", age50)


print("")


pmoney = int(input("how much money do you get a month? "))
pbill = int(input("how much is your monthly phone bill? "))
fbill = int(input("how much do you spend on food each month? "))
pof = int(input("how much do you spend on going out with friends each month? "))

moneyleft = pmoney - pbill - fbill - pow

print ("at the end of a month, you will have £",moneyleft ,"left")












