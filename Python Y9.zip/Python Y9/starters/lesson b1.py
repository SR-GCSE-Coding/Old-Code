import turtle           #Library of turtle drawing commands/methods
wn=turtle.Screen()
q=turtle.Turtle()       #changes the command so you type "Q" instead of "turtle"
q.penup()               #raises the pen meaning movements don't draw a line
q.setpos(50,50)         #sets the turtle at the position without drawing(?)
q.width(2)              #set the width of the pen to 2 pixels so that lines are two pixels wide
q.color("black")        #sets the pen colour to black
q.pendown()             #puts the pen on the canvas allowing drawing 
q.begin_fill()          #sets the start position for fillin the drawn shape
q.circle(30)            #draw a circle that has 30 pixels 
q.color("red")          #sets the pen colour to red making ll lines and fills red
q.end_fill()            #fills the last shape that was drawn
q.hideturtle()          #hides the turtle arrow
