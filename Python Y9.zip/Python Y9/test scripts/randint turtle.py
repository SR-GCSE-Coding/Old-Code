from turtle import *
from random import randint

t=Turtle()
t.pensize(10)
t.speed("fastest")
colors=["green","magenta","red"]


for i in range(1,801):
    x=(i/2)
    y=randint(0,2)
    t.color(colors[i%3])
    t.fd(50-i+x-y)
    t.lt(46+y)
