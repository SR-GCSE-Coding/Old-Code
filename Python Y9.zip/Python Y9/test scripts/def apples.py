def apples():
    print("apples are good")
    print("but not as good as bananas")

def pears():
    print("pears are better than apples")
    print('but still not as good as bananas')

def fruit():
    print('-----')
    apples()
    print('-----')
    pears()
    print('-----')
