from turtle import *

forward(-100)
