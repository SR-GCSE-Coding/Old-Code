num1 = input ("please enter a number: ")
num2 = input ("please enter a second number: ")

num1 = int(num1)
num2 = int(num2)

num3 = num1 + num2

print ("your answer is: " , num3)

print (num3 , "is a number")
