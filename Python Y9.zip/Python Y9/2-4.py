color = input("what is your favourite colour? ")

if color == "blue":
    print("what a nice colour")

else:
    print("that colour sucks")

