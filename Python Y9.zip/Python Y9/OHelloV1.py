print ("Hi")
print ("Hello")



