temperature = float(input("Enter the temperature "))
#this code asks for an input and saves it as a float number, a number that can have decimals

if temperature > 25:
    print("Too hot")
#this code prints "too hot" if the input is bigger than 25

elif temperature < 15:
    print("Too cold")
#if the input is less than 15, this code prints "too cold"

else:
    print("Just right")
#if the code is any other number, it prints "just right"
