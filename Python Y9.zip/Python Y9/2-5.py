age = int(input("how old are you? "))

age50 = age + 50

print ("in 50 years you will be", age50)
