num = 2
#this changes the number to mulyiply by


for x in range (1, 11):
    print(num, "x", x, "=", num*x)


#the code (1,11) shows the numbers it multiplys by, it starts with num x 1
#and does a total of 10 multiplications
