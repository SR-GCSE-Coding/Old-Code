#import required items
import random
from random import randint
import turtle
from turtle import*

#constants
rock = 1
paper = 2
scissors = 3

#define display message
def dm():
    print('Welcome to Rock Paper Scissors, a game of chance to see who will')
    print('outsmart the other. This game is Man VS Computer.')
    print('The program will select a random integer and then ask you for an integer')
    print('1 for Rock 2 for paper or 3 for Scissors. The program will then tell')
    print('you who won the game.')
    print('GOOD LUCK!')

#define computer number choice using a random integer
def get_random():
    import random

    #generate random int
    computer = random.randint(1, 3)
    return computer

#define the game code
def play_game():

    #get random input
    computer = get_random()

    play = int(input('Select 1 for Rock, 2 for Paper, or 3 for Scissors: '))
    #validate input
    if play == '1' or play == '2' or play == '3':
        play == True
    elif play == False:
        print('Error: Invalid Entry')
        play = input('Please enter 1 for Rock, 2 for Paper, or 3 for Scissors: ')
    else:
        print("TEST")

    if play == computer:
        print('Tie Score, Please try again')
        tie_score = 1

    else:
        get_score(computer, play)

    print('The computer chose:', computer)
    print('The player chose: ', play)

#define the main function
def main():
    kg = 'y'

    cw = 0
    pw = 0
    ts = 0

    dm()

    kg = int(input('Would you like to play again? (Y for yes): ')

    if kg == ('y') or kg == ('Y'):
             play_game()

    break

    
