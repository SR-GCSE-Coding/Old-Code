from random import randint

un=["1","2","3","4","5","6","7","8","9"]
te=["1","2","3","4","5","6","7","8","9"]

lotnums = []
#the lists un and te provide the numbers that can be used to generate the final lotto numbers and lotnums are the final lotto numbers that are put into one list

for i in range(0,8):
    num1 = randint(0,8)
    num2 = randint(0,8)
    un1 = un[num1]
    te1 = te[num2]
    tot1 = un1+te1
    lotnums.append(tot1)
#this code will generate a random number and use it to select two numbers from the lists un and te and adds them to each other, it will then add the final two digit number to
#lotnums and repeat 9 times, until there are 9 numbers in the lotnums list

print("Your numbers are" ,lotnums)
#this will print the final lotnums list
