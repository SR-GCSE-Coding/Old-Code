from random import randint

keep_going = 'y'
l1=["yellow","red","blue","green"]
l2=["left hand","left leg","right hand","right leg"]

while keep_going== 'y' or keep_going=='Y':
    lnum1=randint(0,3)
    lnum2=randint(0,3)
    x=l1[lnum1]
    y=l2[lnum2]
    print("Move" ,y, "to" ,x)
    keep_going = input('would you like to play again? Y/N: ')
    print('')
