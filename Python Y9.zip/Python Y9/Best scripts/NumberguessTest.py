import random
compnum = random.randint(1,10)
playagain = input
guesses = input(False + True)
usernum = input

if playagain == True:
    usernum = input("guess a number")
    guesses = 1
    if usernum == compnum:
        print ("Correct")
        playagain = False
    elif usernum < compnum:
        print ("Too low")
        playagain = True
    else:
        print ("Too high")
        playagain = True
if usernum == compnum:
    print ("You took" , guesses , "turns to get it right")
