pmoney = int(input("how much money do you get a month? "))
pbill = int(input("how much is your monthly phone bill? "))
fbill = int(input("how much do you spend on food each month? "))
pof = int(input("how much do you spend on going out with friends each month? "))

moneyleft = pmoney - pbill - fbill - pow

print ("at the end of a month, you will have £",moneyleft ,"left")
