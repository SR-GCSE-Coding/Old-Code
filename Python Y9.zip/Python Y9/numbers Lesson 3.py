spider_legs = int(7)
ant_legs = int(8)
if spider_legs <= ant_legs:
    print ("true")

else:
    print("false")
