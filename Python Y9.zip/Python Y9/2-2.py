num1 = input ("please enter a number: ")
num2 = input ("please enter a second number: ")
#this code takes two numbers and stores them as a variable

num1 = int(num1)
num2 = int(num2)
#this code converts the variables to an integer number

num3 = num1 * num2 * 2
#this code multiplies the two given numbers by each other and then by two

print ("your answer is: " , num3)
#this shows the final result

print (num3 , "is an even number")
