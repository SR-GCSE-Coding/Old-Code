num = "0"

while num!=10:
    num = int(input("try to guess my number "))

print("you guessed my number correctly")
