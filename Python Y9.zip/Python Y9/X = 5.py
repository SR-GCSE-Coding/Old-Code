X = 5
print (X + 2)
