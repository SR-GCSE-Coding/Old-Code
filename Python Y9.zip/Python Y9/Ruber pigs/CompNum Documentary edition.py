import random
compnum = random.randint(1,100)
#this code will import the random module and create a random number called compnum
#which can be the number 1 to 100
while playagain == True:
    usernum = int(input("guess a number: "))
    guesses = 1
    if usernum == comnum:
        print ("correct")
        playagain = False
#this should compare the user number and computer number together and say the answer
#is correct if they are the same but there is a typo where "compnum" is written as
#"comnum"
        elif usernum < compnum:
        print ("too high")
#this will say the number is too high if the number given is less than the random number
#this is a logic error, if else it will print too low when the number would be too high
    else:
        print ("too low")
print ("you took" , guesses "turns to get it right")
#this will say how many tries it took to answer the number correctly but there is a missing comma
