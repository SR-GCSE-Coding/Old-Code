"""NumberSize but it has hash symbols that highlight errors"""
num1 = input("enter a number: ")
num2 = int(input("enter another number: ")
#for num2 there should be a second bracket at the end to make it int(input())
if num1 > nums:
           print (num1 , "is bigger than" , num2)
#"nums" should be "num2" and "num1 , " won't work because num1 is not recorded as an integer
else:
           print(num1 , "is smaller than" , num2)
#this is fine
