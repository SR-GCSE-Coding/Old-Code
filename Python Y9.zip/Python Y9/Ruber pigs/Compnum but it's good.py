import random
compnum = random.randint(1,100)
while playagain == True:
    usernum = int(input("guess the number: "))
    guesses = 1
    if usernum == compnum:
        print ("Correct")
        Playagain = False
    elif usernum < compnum:
            print ("Too low")
    else:
        print ("Too high")
print("you took" , guesses , "turns to get it right")
