import random
compnum = random.randint(1,10)
usernum = int(input(" enter a numbe between 1 and 10")
if usernum == compnum:
              print ("you guessed right")
