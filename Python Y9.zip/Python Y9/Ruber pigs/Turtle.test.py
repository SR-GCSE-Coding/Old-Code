import turtle
wn=turtle.Screen
for i in range (30):
    turtle.forward(5)
    turtle.right(85)
