import turtle
wn=turtle.Screen
def step2():
    turtle.forward(100)
def tiltr():
    turtle.right(10)
def tiltl():
    turtle.left(10)
def step1():
    turtle.forward(10)
def tiltr2():
    turtle.right(90)
def tiltl2():
    turtle.left(90)
for i in range(36):
    step2()
    tiltr2()
    step2()
    tiltr2()
    step2()
    tiltr2()
    step2()
    tiltr2()
    tiltr()
