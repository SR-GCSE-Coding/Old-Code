from turtle import *



pendown()
for i in range (0,5):
    forward(100)
    right(72)
penup()
