from turtle import *

pendown()
for i in range (0,4):
    forward(100)
    right(90)
penup()
