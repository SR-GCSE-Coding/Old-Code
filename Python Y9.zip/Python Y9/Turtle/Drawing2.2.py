import turtle
win=turtle.Screen()
turtle.shape("turtle")
t=turtle.Turtle()
x = 200
y = 90
turtle.forward(x)
turtle.left(y)
turtle.forward(x)
turtle.left(y)
turtle.forward(x)
turtle.left(y)
turtle.forward(x)
turtle.left(y)
