from turtle import *

pendown()
for i in range (0,6):
    forward(50)
    right(60)
penup()
