from turtle import *


t=Turtle()
t.pensize(10)
colors = ["red","green","magenta","blue"]

t.speed("fastest")




pendown()

for i in range (1,4001):
    x=(i*2)
    t.color(colors[i%4])
    t.fd(i)
    t.lt(133)


penup()


