from turtle import *

t=Turtle()
t.pensize(20)
colors=["green","red","blue","magenta"]


t.speed(500)

for i in range(0,8000):
    t.color(colors[i%4])
    t.fd(i)
    t.left(36)

   
