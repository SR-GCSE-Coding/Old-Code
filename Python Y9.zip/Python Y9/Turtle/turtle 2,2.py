from turtle import *

pendown()
for i in range (0,4):
    forward(200)
    right(90)
penup()
