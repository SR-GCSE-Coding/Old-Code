from turtle import *

width(50)

pendown()
for i in range (0,5):
    forward(100)
    right(72)
penup()
