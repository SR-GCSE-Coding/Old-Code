from turtle import*



width(1)
pendown()
color ("red" , "green")


speed(100)

for i in range(0,500):
    forward(i)
    right(145)
  


penup()
