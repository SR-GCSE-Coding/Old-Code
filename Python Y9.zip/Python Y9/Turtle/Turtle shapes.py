from turtle import *



width(1)
pendown()
color ("red" , "green","magenta")


for i in range(0,500):
    turtle.forward(i)
    turtle.right(145)
  


penup()
