import turtle
wn=tutle.Screen()
a=turtle.Turtle()
for i in range(5):
	a.forward(100)
	a.left(72)
