import turtle
wn=tutle.Screen()
a=turtle.Turtle()
for i in range (36):
	a.right(10)
	a.forward(10)
