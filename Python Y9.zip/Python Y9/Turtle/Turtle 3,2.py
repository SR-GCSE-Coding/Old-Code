from turtle import*

width(8)
pendown()
begin_fill()
color ("green" , "red")
for i in range(0,6):
    forward(150)
    left(60)

end_fill()
penup()
