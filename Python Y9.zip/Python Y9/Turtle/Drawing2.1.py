import turtle
win=turtle.Screen()
t=turtle.Turtle()
t.shape("turtle")
x1 = 200
x2 = 100
y1 = 90
y2 = 45
y3= 135
t.fd(x1)
t.left(y1)
t.fd(x1)
t.left(y1)
t.fd(x1)
t.left(y1)
t.fd(x1)
t.right(y3)
t.forward(x2)
t.right(y2)
t.forward(x1)
t.right(y1)
t.forward(x1)
t.right(y2)
t.forward(100)
t.right(y3)
t.forward(x1)
t.right(y2)
t.forward(x2)

