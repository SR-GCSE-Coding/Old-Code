import turtle
wn=turtle.Screen
turtle.penup()
turtle.backward(250)
turtle.pendown()


def up():
    turtle.penup()
def down():
    turtle.pendown()
def move():
    turtle.forward(10)


def dash():
    move()
    up()
    move()
    down()



for i in range(25):
    dash()
    
    
