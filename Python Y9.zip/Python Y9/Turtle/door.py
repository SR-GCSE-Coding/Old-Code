from turtle import *
import turtle

wn=turtle.Screen()
t=turtle.Turtle()
t.shape=("turtle")
t.speed("fastest")

def door():
    t.speed("fastest")
    t.color("maroon")
    t.begin_fill()
    t.lt(90)
    t.bk(100)
    t.fd(100)
    for i in range(0,180):
        t.fd(1)
        t.rt(1)
    t.fd(200)
    t.rt(90)
    t.fd(115)
    t.rt(90)
    t.fd(100)
    t.end_fill()
    

def doorknob():
    t.speed("fastest")
    t.color("yellow")
    t.penup()
    t.rt(90)
    t.fd(90)
    t.lt(90)
    t.fd(25)
    t.rt(90)
    t.pendown()
    t.begin_fill()
    t.circle(5)
    t.end_fill()

door()
doorknob()
t.penup()
t.goto(20,20)
    
