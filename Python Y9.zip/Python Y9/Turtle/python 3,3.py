from turtle import*

width(8)
pendown()

speed(500)

for i in range(0,100):
   right(40)
   forward(150)
   left(130)


