num1 = int(input("enter a number: "))
num2 = int(input("enter another number: "))
if num1 > num2:
    print (num1 , "is bigger than" , num2)
else:
    print (num1 , "is smaller than" , num2)
