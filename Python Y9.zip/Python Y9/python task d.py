from turtle import*

width(4)
pendown()
begin_fill()
color ("green" , "#00ff00")

speed(50)

for i in range(0,8):
    forward(150)
    left(45)

for i in range (0,6):
    forward(150)
    left(60)

for i in range(0,4):
    forward(150)
    left(90)

for i in range(0,3):
    forward(150)
    left(120)

end_fill()
penup()
