import turtle
wn=turtle.Screen()
q=turtle.Turtle()
q.right(90)
q.forward(50)
q.left(180)
q.forward(100)
q.right(90)
for i in range(45):
        q.forward(4)
        q.right(4)
q.forward(4)
q.right(90)
q.forward(70)
