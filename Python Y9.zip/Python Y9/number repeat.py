

for x in range (6):
    print(x+5)
