print("STAY")
print("CALM")
print("AND")
print("LEARN")
print("PYTHON")

