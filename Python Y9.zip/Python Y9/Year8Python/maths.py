Variable1 = 1
Variable2 = 12
Variable3 = 123
Variable4 = 1234
Variable5 = 12345


print(Variable1+Variable3)
