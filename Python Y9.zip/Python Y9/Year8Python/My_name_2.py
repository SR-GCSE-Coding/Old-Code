print("what is your name? ")
my_name = input()
print("hello " + my_name + ", nice to meat you ")
    

