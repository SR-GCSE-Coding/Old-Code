print ("my name is Joe")
my_name=input("nice to meat you Joe")
print ("hello" + my_name + "nice to meat you")



