print ("what is 21 X 2?")
answer = input()
answer = int(answer)
if answer == 42:
    print ("correct")
