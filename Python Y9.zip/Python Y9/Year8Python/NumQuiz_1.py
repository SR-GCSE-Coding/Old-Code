print("What is 2+2?")
answer = input()
answer = int(answer)
if answer == 4:
    print("Well Done")
else:
    print ("No")

    

    

