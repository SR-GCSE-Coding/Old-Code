print("Where am I?")


