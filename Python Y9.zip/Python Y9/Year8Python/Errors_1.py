print('Please enter your name: ')
#"P" in print is uppercase
#~~~~~~~~~~ignore~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
my_name = input
print("my_name, what age are you?")
#~~~~~~~~~~ignore~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
my_age = input()
my_age = int(my_age)
#"integer" abbreviated to "int"
if my_age == 11:
    print('You must go to Secondary school')
else:
     print('You must go to Primary school')
