bread = 1.50
butter = 0.20
olives = 1000
cowmeat = 50
CHICKEN = 20.52
#olives are expensive

print (bread+bread+bread+butter)
#by S.Rielly
#28/03/2017
print(olives*5/bread)
print(cowmeat*olives)
print(cowmeat*olives/bread+butter*2)
print(CHICKEN)
