print("Hello\nWorld")
