print("I Like Python And Right Now I Am Learning To Program!")
