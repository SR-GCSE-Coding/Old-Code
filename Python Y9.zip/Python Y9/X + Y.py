X = 'Hello '
Y = 'there '
colour2 = 'green '
colour = 'Brown '
animal = 'Puppy '
P = 'Python '
species = 'Pug '
colour3 = 'blue '
footwear = 'sandals '
T = 'the '

print (X + Y)

print ('I love ' + P)

print (colour + animal)

print (colour2 + P)

print (colour + species + animal)



#A = '10'
#B = '50'
#C = '250'
#print (A*B)
#This doesn't work because Python cannot use letters, even variables, for maths

print (colour3 + footwear)


