scores = [25,23,15,17,45,53,34,89]
#this code sets the values of the variables "scores"

print(scores)
#this code prints the list of scores

print(scores[3])
#this code prints the score in position 3, but python counts from 0 to so
#the 3rd score is actually 17

scores[7]=27
#this changes the 7th number, 89, to 27

print(scores)
#this prints the changed scores

for i in range (0,8):
    scores[i]=0
#this makes the score in the position equal to i 0, it does this 8 times
#,changing all the numbers to 0

print(scores)
#prints the changed numbers
