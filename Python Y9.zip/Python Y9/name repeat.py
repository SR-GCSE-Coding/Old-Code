for x in range (10):
    print("Scott")
