num1 = int(42)
num2 = int(666)
if num2 != num1:
    print ("true")

else:
    print ("false")
