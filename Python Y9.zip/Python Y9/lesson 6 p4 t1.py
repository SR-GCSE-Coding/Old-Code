from random import randint
column_1 = ["1", "2", "3", "4", "5", "6 "]
column_2 = ["1", "2", "3", "4", "5", "6 "]
#this code generates two lists with 6 variables

number = randint(0, 5)
word_1 = column_1[number]
#this code chooses a number from the list based on a random integer given

number = randint(0, 5)
word_2 = column_2[number]
#this code chooses a number from the list based on a random integer given


Dice = "You have rolled " + word_1 + ", " + word_2 + " "
print(Dice)
#this code creates a sentence with the numbers and prints it 
