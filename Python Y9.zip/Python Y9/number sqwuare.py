


for i in range (1,13):
    print(i, "x", i, "=", i*i)
