from time import time

time_permitted = 30
start_time = time()
end_time = time()
time_taken = end_time - start_time

p=("The quick brown fox jumps over the lazy dog")

print("Enter the following phrase")
print(p)

reply1 = input()

print("")
print("")

print("Enter the phrase again ")
print(p)

reply2 = input()

print("")
print("")

if reply1 == p and reply2 == p and time_taken < time_permitted:
    print("You passed the test ")

else:
    print("You failed the test")


