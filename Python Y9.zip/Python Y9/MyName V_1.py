print ("My name is Scott")
