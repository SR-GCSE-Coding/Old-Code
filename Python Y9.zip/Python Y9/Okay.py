print ('I think python is okay')
print ('I like pytho')
print ('I love python')
print ('Me encanta Python')
X = 'I love '
print (X + 'Python')
