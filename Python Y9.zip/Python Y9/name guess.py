name = " "

while name!="Scott":
    name = input("try to guess my name ")

print("you guessed my name correctly")
