fruits = ["apple","pear","banana","orange","lemon","pineapple"]
#this code adds 6 words to the variable "fruits"

fruits[2] = "cherry"
#this code changes the second variable, pear, to cherry

print(fruits)
#this code prints the "fruits" variable, with cherry replacing pear

size = len(fruits)
#this code counts the total number of values in the variable"fruits"

print(size)
#this code prints the variable "size" which is equal to the total number of variables
#, 6

fruits.append("apricot")
#this code adds another value to the end of "fruits", apricot

print(fruits)

fruits.remove("orange")
#this code removes "orange" from "fruits"

print(fruits)
