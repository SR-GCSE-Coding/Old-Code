fruits = ["apple","pear","banana","orange","lemon","pineapple"]

print(fruits)
#this code will display all of the fruits listed above

print(fruits[3])
#this will the print the fruit in the third place, orange
