
name=input("What is your first name? ")
greeting="Nice to meet you "
print (greeting+name)

class2 = input ('what is your favourite class? ')
classAnswer = '? that is a good choice'
print (class2 + classAnswer)
