dogs_sleep = int(13)
cats_sleep = int(17)
if dogs_sleep >= cats_sleep:
    print ("true")

else:
    print ("false")
