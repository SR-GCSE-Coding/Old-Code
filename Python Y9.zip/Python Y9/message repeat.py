x = input("please enter a message: ")
i = int(input("please enter how many times to repeat the message: "))

for n in range(i):
    print(x)
