Flavour = input ('what is your favourite ice-cream flavour? ')
print (Flavour + ' is a good flavour but I prefer bubblegum')

