age = int ( input ('please enter your age '))

print ('you will be ' , age + 1 , ' years old next year')
