results = [25,23,15,17,45,53,34,89]

print(results)

print(results[3])
#this needs to have an s on the end otherwise python thinks it is an unspecified variable

results[4,7,8] = 27
#you can't change multiple numbers all at once, and there is only values 0-7

print(results)

for i in range[0,8]:
    scores[I]=0
    #scores is a different variable and the I needs to be lower case

print(results)
