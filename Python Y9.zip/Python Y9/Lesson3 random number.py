import random
random_num = random.randint(1,10)

print ("================")
print ("guess the number")
print ("================")

guess = int(input("please enter a number  between 1 and 10 "))

print()

if guess==random_num:
            print ("well done, you've guessed the number correctly")

elif guess>10:
            print("that number is too big")

else:
            print ("sorry, your guess was wrong, the actual number was ",random_num)



