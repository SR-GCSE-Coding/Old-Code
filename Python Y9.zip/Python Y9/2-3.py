print ("this code will work out the volume of a cuboid, make sure all the measurements are in the same units")

side1 = input("enter the length of the first side: ")
side2 = input("enter the length of the second side ")
side3 = input("enter the length of the third side ")

side1 = int(side1)
side2 = int(side2)
side3 = int(side3)

volume = side1 * side2 * side3

print ("the volume of the cube is: " , volume)

