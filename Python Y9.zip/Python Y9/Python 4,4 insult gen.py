from random import randint
#this code allows you to generate a random integer

col1 = ["artless ","churlish ","droning ","loggerheaded ","puny ","rank ","saucy ","vain ","warped ","weedy "]
col2 = ["bat-fowling ","clay-brained ","dizzy-eyed ","fat-kidneyed ","fly-bitten ","half-faced ","idle-headed ","ill-nurtured ","onion-eyed ","pox-marked ","swag-bellied ","weather-bitten "]
col3 = ["bladder ","bugbear ","codpiece ","lout ","maggot-pie ","miscreant ","strumpet ","wagtail "]
#this code creates three variables with different words as the values

num1 = randint(0,9)
num2 = randint(0,11)
num3 = randint(0,7)
#this code chooses a random number

word1 = col1[num1]
word2 = col2[num2]
word3 = col3[num3]
#this code uses the random number from earlier to choose a word from each variable

print ("thou " + word1 + word2 + word3)
#this code prints the chosen words and prints them, prefaced with the word 'thou'
#which is early-modern english for 'you'
