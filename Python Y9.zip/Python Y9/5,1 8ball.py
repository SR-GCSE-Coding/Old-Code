from random import randint

reply = ["no","no","no","yes","yes","yes","no","no","no","yes","yes","yes","possibly","possibly","possibly","possibly","possibly","possibly","when pigs fly","when pigs fly","when pigs fly","when pigs fly","when pigs fly","when pigs fly","9/11 was an inside job","","very","very","very","very","very","very","not until I'm cool","not until I'm cool"]
notcool = ["Will","Connor","Kacper","Scott"]

quest=input("what question do you want answered? ")

num = randint(0,32)

rep1 = reply[num]

print(rep1)


