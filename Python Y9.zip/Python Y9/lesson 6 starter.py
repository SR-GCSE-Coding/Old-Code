#Amazing starter code



print("this code is amazing and better than anything anyone else has done")

g = int(input("how old are you? "))

if g>19:
    print("you are an adult")

elif g<13:
    print("you are a chld")

else:
    print("you are a teenager")
