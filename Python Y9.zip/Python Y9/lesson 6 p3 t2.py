print("Enter the following phrase")
print("The quick brown fox jumps over the lazy dog")
#this code asks you to print the phrase and then shows you the phrase

reply = input()
#this code takes what you typed as a variable

if reply == "The quick brown fox jumps over the lazy dog":
    print("You passed the test")
#this code checks your answer and the original phrase and if they match, prints
#that you passed the test
    
else:
    print("you failed the test")
#if you answered with anything else, this code is run and prints that you
#failed the test


