s = int(input("please enter how many stars you want per row: "))
r = int(input("please enter how many rows you want: "))

print (r*(s * "*"))
