'''Made by me
 adventure game'''




#imports
import random


#variables
greeting = " welcome to this game about adventuring, made by Me "

difficulty=1
monster_hit = int(random.randint(5,100)*difficulty)
monster_hit_2 = int(random.randint(10,50)*difficulty)
health =int(100)*difficulty/2
#this health increase with difficulty makes the game seem a bit more
#fair when it really isn't
#100/2=50 5-100*1=5-100 50 chances to die , 45 to survive
health_left = health - monster_hit
monster_health = int(random.randint(20,70)*difficulty/2)


#calculations
user_name = input("enter your first name: ")
print("")
print ("--------------------------------------------------------------")
print("")
print ("hello " +user_name.title() + "," + greeting)
print("")
print("your starting health is " + str(health) + "  points")
print("")
print ("the monster's health is " + str(monster_health) = " points")
print ("you have been hit for " , monster_hit , " points")
print("")
print ("you have" , str(health - monster_hit) , "health left")
print("")
if (health_left <= 0):
    print("you have been killed ")
else:
    print("you have survived")
print("")
print ("--------------------------------------------------------------")
print("")
if (health_left > 0):
    print ("you have been hit again for" , str(monster_hit_2) , "damage")
    print ("you have" , str(health_left - monster_hit_2) , "health left now")
    
    

