Name = input ('what is your name? ')
Greeting = 'good day '
niceName = 'What a nice name '
print (niceName + Name)
Name2 = input ('what is your second name?  ')
print (Greeting + Name + Name2 )


