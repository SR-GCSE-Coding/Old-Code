variable1 = int(7)
variable2 = int(8)
if variable1 >= variable2:
    print ("true")

if variable1<=variable2:
    print ("false")
