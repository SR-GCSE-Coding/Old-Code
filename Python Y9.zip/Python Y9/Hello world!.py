print ('hello world!')
print ('Goodbye world!')

Variable1 = 0.5
Variable2 = 20
Variable3 = -25

print (Variable1*Variable2+Variable3)

X ="Hello"

print (X+" world!")
