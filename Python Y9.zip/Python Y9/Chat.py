Name = input ('What is your name? ')
Greeting = 'what a nice name! good to meet you '
print ( Greeting + Name)
food = input ('what is your favourite food?')
print ('that is a good choice, ' + Name) 
age = input ('how old are you?')
print(Name + ", are you really " + age + " years old?")

